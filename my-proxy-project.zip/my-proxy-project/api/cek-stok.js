export default async function handler(req, res) {
  const { product } = req.query;

  const username = 'alekardiansyah418@gmail.com';
  const password = 'ardistore';
  const apiKey = 'glAle03l0kmRyAh418';
  const apiUrl = `https://api.hesda-store.com/v2/cek_stok_akrab?hesdastore=${apiKey}&product=${encodeURIComponent(product)}`;

  try {
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Authorization': 'Basic ' + Buffer.from(username + ":" + password).toString('base64'),
        'Content-Type': 'application/json'
      }
    });

    const data = await response.json();

    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ error: 'Gagal mengambil data stok', detail: error.message });
  }
}
